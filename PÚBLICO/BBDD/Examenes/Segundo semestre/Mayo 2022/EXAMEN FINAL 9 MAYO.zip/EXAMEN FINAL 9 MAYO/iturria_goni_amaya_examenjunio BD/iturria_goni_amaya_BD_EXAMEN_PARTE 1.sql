-----------------------------------------------
--------- 2ª EVAL. EXAMEN - 09/05/2022  -------
------------------- PARTE 1 -------------------
-----------------------------------------------
-----------------------------------------------
--- Nombre y apellidos:AMAYA ITURRIA GOÑI


-- =================================================================================
--   Ejercicio 1 (1p)
--   SILVIA CARRASCO devolvió el ejemplar 1 de "KILL BILL VOL.1" un día más tarde
--   de la fecha que quedó registrada. 
-- 
--   Utiliza una sentencia de actualización para modificar los datos. 
--   La sentencia debe utilizar el nombre del socio, el titulo de la película y 
--   la fecha de devolución que quedó registrada.
-- =================================================================================
UPDATE ALQUILA
SET FECHA_DEVOLUCION = FECHA_DEVOLUCION +1
WHERE DNI = (SELECT DNI FROM SOCIO WHERE NOMBRE ='SILVIA CARRASCO') AND IDPELICULA =(SELECT ID FROM PELICULA WHERE TITULO = 'KILL BILL VOL.1');


-- =================================================================================
--   Ejercicio 2 (1p)
--   Elimina de la base de datos todos aquellos ejemplares de películas que hayan sido devueltos nunca
--   han sido alquilados. 

--EJERCICIO 2 Parte 1: Eliminar solo los que no se han alquilado nunca.
-- 
--   La sentencia debe funcionar independientemente de los datos actuales de la base de datos.
-- =================================================================================

DELETE FROM EJEMPLAR
WHERE (IDPELICULA, NUMERO) NOT IN (SELECT IDPELICULA, NUMERO FROM ALQUILA);


-- =================================================================================
--   Ejercicio 3 (1p)
--   A) Crea una nueva tabla denominada "REPARACIONES" con los campos id de pelicula, título de película,
--   numero de ejemplar, estado y urgente. Escoge la clave primaria más adecuada.
-- 
--   B) Inserta en la nueva tabla los datos de aquellos ejemplares cuyo estado sea malo o regular
--   Si el estado es malo, en urgente se almacenará SI y si es regular se almacenará NO.
-- 
--   La sentencia debe funcionar independientemente de los datos actuales de la base de datos.

 
-- =================================================================================
CREATE TABLE REPARACIONES(
ID NUMBER,
TITULO VARCHAR2(40),
NUMERO NUMBER,
ESTADO VARCHAR2(40),
URGENTE VARCHAR2(2) DEFAULT 'NO',
PRIMARY KEY (ID,NUMERO),
CHECK (URGENTE IN ('NO', 'SI')) 
);
-- esta parte del ejercicio  me devuelve resultado vacio y no encuentro la tabla reparaciones aunque sí la he creado.
INSERT INTO REPARACIONES(
SELECT PELICULA.ID, PELICULA.TITULO, EJEMPLAR.NUMERO, EJEMPLAR.ESTADO, REPARACIONES.URGENTE, EJEMPLAR.IDPELICULA
FROM PELICULA
JOIN EJEMPLAR ON PELICULA.ID = EJEMPLAR.IDPELICULA
WHERE ESTADO = 'MALO' OR ESTADO ='REGULAR');

SELECT *FROM REPARACIONES;





-- =================================================================================
--   Ejercicio 4 (3,75p)
--   Crea un trigger denominado “ejercicio4” en la tabla ALQUILA que realice las siguientes comprobaciones 
--   antes de insertar o modificar un registro de la tabla.
--
--   A) Si se está insertando, habrá que realizar las siguientes acciones:
-- 	   1. Si el ejemplar especificado ya está alquilado, lanzará el error "ORA-20021: El ejemplar aparece como alquilado"
--     2. Si el socio ya tiene 3 películas alquiladas, lanzará el error "ORA-20022: El socio ha llegado al límite de películas en alquiler"
--     3. Si los datos están correctos, habrá que actualizar el campo "alquilado" con valor "S" en el registro que corresponda de la tabla EJEMPLAR y se guardará
--        como fecha de alquiler la actual.
--  B) Si se está actualizando, habrá que realizar las siguientes acciones:
--     1. Si la fecha de devolución está vacía, no se realizará ninguna acción.
--     2. Si la fecha de devolución es anterior a la de alquiler, lanzará el error "ORA-20024: La fecha de devolución debe ser posterior a la de alquiler"
--     3. Si la fecha de devolución es correcta, habrá que actualizar el campo "alquilado" con valor "N" en el registro que corresponda de la tabla EJEMPLAR
--     
--
--  Pon tantos ejemplos como sean necesarios para verificar todos los casos del trigger. Especifica en cada ejemplo a que caso se corresponde.
-- =================================================================================

create or replace trigger ejercicio4 
 before insert or update on ALQUILA
 for each row
declare
  ejemplarAlquilado int;
  cuantasPeliculas int;
  peliculaAlquilada int;

 begin
   if inserting then
     select count(*) into ejemplarAlquilado from alquila where idpelicula = :new.idpelicula and numero = :new.numero and fecha_devolucion is null;
     select count(*) into cuantasPeliculas from alquila where dni = :new.dni and fecha_devolucion is null;
     select count(*) into peliculaAlquilada from alquila where dni = :new.dni and idpelicula = :new.idpelicula and fecha_devolucion is null;
     
     --1. El ejemplar está alquilado
     IF (ejemplarAlquilado = 1) THEN 
          RAISE_APPLICATION_ERROR(-20021, 'El ejemplar aparece como alquilado'); 
     END IF; 
     --2. El socio ya tiene 3 películas alquiladas
     IF (cuantasPeliculas >= 3) THEN 
          RAISE_APPLICATION_ERROR(-20022, 'El socio ha llegado al límite de películas en alquiler'); 
     END IF; 
    
     -- Actualizamos el estado del ejemplar para que conste como alquilado
     update ejemplar set estado = 'S' where idpelicula = :new.idpelicula and numero = :new.numero;
     
   end if; 
   if updating then
     --1. La fecha de devolucion es anterior a la fecha de alquiler
     IF (:new.fecha_devolucion < :new.fecha_alquiler) THEN 
          RAISE_APPLICATION_ERROR(-20024, 'La fecha de devolución debe ser posterior a la de alquiler'); 
     END IF; 
   
     
     -- Actualizamos el estado del ejemplar para que conste como libre
     update ejemplar set estado = 'N' where idpelicula = :new.idpelicula and numero = :new.numero;
   
   end if; 
 end ;
/