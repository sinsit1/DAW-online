-----------------------------------------------
--------- 2ª EVAL. EXAMEN - 09/05/2022  -------
------------------- PARTE 2 -------------------
-----------------------------------------------
-----------------------------------------------
--- Nombre y apellidos: AMAYA ITURRIA GOÑI
-----------------------------------------------
SET SERVEROUTPUT ON;
-- =================================================================================
--   Ejercicio 1 (0,5p)
--   Crea el tipo de objeto Telefono con los atributos: tipo y numero
--   Crea el tipo ListaTelefonos como una lista de máximo 5 numeros de teléfono
-- ================================================================================
CREATE TYPE telefono AS OBJECT
(
tipo VARCHAR2(20),
numero NUMBER(9)
);
/

CREATE OR REPLACE TYPE ListaTelefonos is varray(5);
/


-- =================================================================================
--   Ejercicio 2 (0,5p)
--   Crea el tipo de objeto Direccion con los atributos: tipo, via, nombre, numero, ciudad, provincia y codigo postal
--   Crea el tipo ListaDirecciones como una lista de máximo 3 direcciones
-- =================================================================================
CREATE OR REPLACE TYPE  Direccion as object(
tipo VARCHAR2(100),
via VARCHAR2(100),
nombre VARCHAR2(100),
numero NUMBER(10),
ciudad VARCHAR2(100),
provincia VARCHAR2(100),
codigo_postal NUMBER(5)
);
/

-- =================================================================================
--   Ejercicio 3 (0,5p)
--   Crea el tipo de objeto Cliente con los atributos: DNI cliente, nombre de cliente,
--   lista de direcciones y lista de telefonos. 
--   con constructor
--   crea una tabla de clientes cuyo identificador sea el numero de cliente.

--EJERCICIO 3 Parte 2: La última línea del enunciado debe poner lo siguiente

--crea una tabla de clientes cuyo identificador sea el DNI del cliente
-- =================================================================================
create or replace type Cliente as object (
    dni varchar2(9),
    nombre varchar2(100),
    direcciones  ListaDirecciones,
    telefonos ListaTelefonos,
    CONSTRUCTOR FUNCTION Cliente(dni VARCHAR2, nombre VARCHAR2, direcciones
       ListaDirecciones, telefonos ListaTelefonos)
     RETURN SELF AS RESULT
);
/
CREATE OR REPLACE TYPE BODY Cliente AS
    CONSTRUCTOR FUNCTION Cliente(dni VARCHAR2, nombre VARCHAR2, direcciones
       ListaDirecciones, telefonos ListaTelefonos)
     RETURN SELF AS RESULT IS
    BEGIN
         SELF.dni := dni;
         SELF.nombre := nombre;
         SELF.direcciones := direcciones;
         SELF.telefonos := telefonos;
         
         RETURN;
    END;

END;

/

CREATE TABLE TablaClientes OF Cliente (dni PRIMARY KEY)
            OBJECT IDENTIFIER IS PRIMARY KEY;

/





-- =================================================================================
--   Ejercicio 4 (1,75p)
--   Utilizando los tipos creados anteriormente, programa un bloque de codigo que inserte dos clientes:
--   A) Cliente 1
--      DNI cliente: 11111111A
--      nombre: Pepe Gomez
--      direccion1: Casa, Calle Caño 68, CP:32720, Esgos (Orense)
--      direccion2: Local, Calle San Sebastián 50, CP:13109, Puebla de Don Rodrigo (Segovia)
--      direccion3: Trabajo Avenida Madrid 128, CP:13001, Segovia (Segovia) 
--      telefono1: Casa 988 871 089
--      telefono2: Movil 684 746 272
--      telefono3: Trabajo 921 267 150
--
--   B) Cliente 2
--      DNI cliente: 22222222B 
--      nombre: María Fernandez
--      direccion1: Casa, Calle Cuesta del Álamo 90, CP:29491, Algatocín (Ciudad Real)
--      telefono1: Móvil 640 858 435
--      telefono2: Trabajo 926 276 960
--
-- Muestra los clientes insertados 
-- =================================================================================

DECLARE
     dni1 dni;
	 dni2 dni;
     cliente1 Cliente;
     cliente2 Cliente;
     direcciones1 ListaDirecciones;
     telefonos1 ListaTelefonos;
     direccion1 Direccion;
     direccion2 Direccion; 
     direccion3 Direccion;
BEGIN  
    -- CLIENTE 1
	dni1:= dni(11111111A);
    direccion1 := Direccion('Casa','Calle Caño 68', 'Esgos', 'Orense', 32720);
    direccion2 := Direccion('Local','Calle San Sebastián 50', 'Puebla de Don Rodrigo', 'Segovia', 13109);
	direccion3 := Direccion('Trabajo','Avenida Madrid 128', 'Segovia', 'Segovia', 13001);
    direcciones1 := ListaDirecciones(direccion1, direccion2, direccion3);
    telefonos1 := ListaTelefonos(988871089, 684746272, 921267150);
	
    insert INTO TablaClientes VALUES (Cliente(11111111A, 'Pepe Gomez', direcciones1,telefonos1));
    
    -- CLIENTE 2
		dni2:= dni(22222222B);
    direccion1 := Direccion('Casa''Calle Cuesta del Álamo 90', 'Algatocín', 'Ciudad Real', 29491);
    direcciones1 := ListaDirecciones(direccion1);
    telefonos1 := ListaTelefonos(640858435, 926276960);
    insert INTO TablaClientes VALUES (Cliente(22222222B, 'María Fernandez', direcciones1,telefonos1));
     
 END;
/
select * from tablaclientes;



